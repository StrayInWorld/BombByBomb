"use strict";
cc._RF.push(module, '41fa25VoCBAL5FNLN2MYj6E', 'one-side-platform');
// Script/one-side-platform.js

"use strict";

// http://www.iforce2d.net/b2dtut/one-way-walls

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {},
    onEndContact: function onEndContact(contact, selfCollider, otherCollider) {
        if (otherCollider.node.group == "Ball") {}
    },

    Dou: function Dou() {
        var ballNum = cc.find("Canvas/Ball");
        //ballNum.children[0].position = cc.p(-0.9,398.8);
        addbrick = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

});

cc._RF.pop();