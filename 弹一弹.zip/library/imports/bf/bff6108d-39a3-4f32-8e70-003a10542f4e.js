"use strict";
cc._RF.push(module, 'bff61CNOaNPMo5wADoQVC9O', 'Globa');
// Script/Globa.js

"use strict";

window.tools = {
    cantouch: true,
    gball: null,
    knif: 0,
    num: 0,
    power: cc.p(0, 0),
    score: 0,
    MarkIdx: 0
};
window.shoujiqiuqiu = 0;

window.hldq = 0;

window.ballNum = 1;
window.bigNum = 0;
window.scaleNum = 0;
window.add = 0;
window.addbrick = false;
window.addnum = 0;

cc._RF.pop();