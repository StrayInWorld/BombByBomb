(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Globa.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bff61CNOaNPMo5wADoQVC9O', 'Globa', __filename);
// Script/Globa.js

"use strict";

window.tools = {
    cantouch: true,
    gball: null,
    knif: 0,
    num: 0,
    power: cc.p(0, 0),
    score: 0,
    MarkIdx: 0
};
window.shoujiqiuqiu = 0;

window.hldq = 0;

window.ballNum = 1;
window.bigNum = 0;
window.scaleNum = 0;
window.add = 0;
window.addbrick = false;
window.addnum = 0;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Globa.js.map
        