(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/one-side-platform.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '41fa25VoCBAL5FNLN2MYj6E', 'one-side-platform', __filename);
// Script/one-side-platform.js

"use strict";

// http://www.iforce2d.net/b2dtut/one-way-walls

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {},
    onEndContact: function onEndContact(contact, selfCollider, otherCollider) {
        if (otherCollider.node.group == "Ball") {}
    },

    Dou: function Dou() {
        var ballNum = cc.find("Canvas/Ball");
        //ballNum.children[0].position = cc.p(-0.9,398.8);
        addbrick = false;
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=one-side-platform.js.map
        